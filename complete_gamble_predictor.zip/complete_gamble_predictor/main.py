
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import os
from PIL import Image, ImageTk
import random

def opposite_card(card):
    return "RED" if card == "BLACK" else "BLACK"

class CompleteGamblePredictor:
    def __init__(self, root):
        self.root = root
        self.root.title("Complete Gamble Predictor")
        self.root.configure(bg="#2E2E2E")

        self.db_init()

        self.card_sequence = []
        self.max_cards = 5
        self.predicted_card = None

        self.load_images()
        self.build_ui()

    def db_init(self):
        self.conn = sqlite3.connect("gamble_predictor.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seq TEXT NOT NULL,
                next_card TEXT NOT NULL
            )
        """)
        self.conn.commit()

    def load_images(self):
        try:
            if os.path.exists("red_card.png"):
                red_img = Image.open("red_card.png").resize((80, 120))
                self.red_image = ImageTk.PhotoImage(red_img)
            else:
                self.red_image = None

            if os.path.exists("black_card.png"):
                black_img = Image.open("black_card.png").resize((80, 120))
                self.black_image = ImageTk.PhotoImage(black_img)
            else:
                self.black_image = None
        except Exception as e:
            print("Greška pri učitavanju slika:", e)
            self.red_image = None
            self.black_image = None

    def build_ui(self):
        self.cards_frame = ttk.Frame(self.root)
        self.cards_frame.pack(pady=10)

        self.card_slots = []
        for i in range(self.max_cards):
            label = tk.Label(self.cards_frame, text="Empty", width=10, height=6, bg="#4D4D4D", fg="white", relief="ridge", borderwidth=2)
            label.grid(row=0, column=i, padx=5)
            self.card_slots.append(label)

        self.choice_frame = ttk.Frame(self.root)
        self.choice_frame.pack(pady=10)

        btn_red = ttk.Button(self.choice_frame, text="RED", command=lambda: self.add_card("RED"))
        btn_red.grid(row=0, column=0, padx=5)

        btn_black = ttk.Button(self.choice_frame, text="BLACK", command=lambda: self.add_card("BLACK"))
        btn_black.grid(row=0, column=1, padx=5)

        btn_generate = ttk.Button(self.choice_frame, text="GENERATE", command=self.generate_prediction)
        btn_generate.grid(row=0, column=2, padx=5)

        btn_reset = ttk.Button(self.choice_frame, text="RESET", command=self.reset_sequence)
        btn_reset.grid(row=0, column=3, padx=5)

        self.prediction_frame = ttk.Frame(self.root)
        self.prediction_frame.pack(pady=10)

        self.prediction_label = tk.Label(self.prediction_frame, text="", font=("Arial", 14), bg="#2E2E2E", fg="white")
        self.prediction_label.pack()

        self.confirm_frame = ttk.Frame(self.root)
        self.confirm_frame.pack(pady=5)

        self.btn_yes = ttk.Button(self.confirm_frame, text="YES", command=lambda: self.confirm_prediction(True))
        self.btn_yes.grid(row=0, column=0, padx=5)

        self.btn_no = ttk.Button(self.confirm_frame, text="NO", command=lambda: self.confirm_prediction(False))
        self.btn_no.grid(row=0, column=1, padx=5)

    def add_card(self, card):
        if len(self.card_sequence) >= self.max_cards:
            messagebox.showinfo("Info", "Već imaš 5 karata. Pritisni RESET za novi niz.")
            return

        self.card_sequence.append(card)
        self.update_card_slots()

    def update_card_slots(self):
        for idx, label in enumerate(self.card_slots):
            if idx < len(self.card_sequence):
                card = self.card_sequence[idx]
                if card == "RED" and self.red_image:
                    label.config(image=self.red_image, text="")
                    label.image = self.red_image
                elif card == "BLACK" and self.black_image:
                    label.config(image=self.black_image, text="")
                    label.image = self.black_image
                else:
                    label.config(text=card)
            else:
                label.config(text="Empty", image="")

    def generate_prediction(self):
        if len(self.card_sequence) != self.max_cards:
            messagebox.showerror("Error", "Unesi tačno 5 karata pre predikcije!")
            return

        seq_str = ",".join(self.card_sequence)
        self.cursor.execute("SELECT next_card FROM predictions WHERE seq = ?", (seq_str,))
        results = self.cursor.fetchall()

        if results:
            predictions = [row[0] for row in results]
            self.predicted_card = max(set(predictions), key=predictions.count)
        else:
            self.predicted_card = random.choice(["RED", "BLACK"])

        self.prediction_label.config(text=f"Predviđena karta: {self.predicted_card}")

    def confirm_prediction(self, is_correct):
        if not self.predicted_card:
            messagebox.showerror("Error", "Nije izvršena predikcija!")
            return

        final_card = self.predicted_card if is_correct else opposite_card(self.predicted_card)

        previous_seq = list(self.card_sequence)
        self.card_sequence.pop(0)
        self.card_sequence.append(final_card)
        self.update_card_slots()

        prev_seq_str = ",".join(previous_seq)
        self.cursor.execute("INSERT INTO predictions (seq, next_card) VALUES (?, ?)", (prev_seq_str, final_card))
        self.conn.commit()

        self.prediction_label.config(text=f"Uneta karta: {final_card}")
        self.predicted_card = None

    def reset_sequence(self):
        self.card_sequence = []
        self.update_card_slots()
        self.prediction_label.config(text="")

    def close(self):
        self.conn.close()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = CompleteGamblePredictor(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
